-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2024 at 12:10 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sklep_informatyczny`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kategorie`
--

CREATE TABLE `kategorie` (
  `ID` int(11) NOT NULL,
  `nazwa_kategorii` varchar(50) DEFAULT NULL,
  `opis` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `kategorie`
--

INSERT INTO `kategorie` (`ID`, `nazwa_kategorii`, `opis`) VALUES
(1, 'Laptopy', 'Najnowsze modele laptopów'),
(2, 'Akcesoria', 'Akcesoria do komputerów'),
(3, 'Drukarki', 'Drukarki i skanery'),
(4, 'Monitory', 'Monitory do komputerów'),
(5, 'Sieci', 'Urządzenia sieciowe'),
(6, 'Audio', 'Słuchawki i głośniki'),
(7, 'Klawiatury', 'Klawiatury do komputera');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `klienci`
--

CREATE TABLE `klienci` (
  `ID` int(11) NOT NULL,
  `imie` varchar(50) DEFAULT NULL,
  `nazwisko` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefon` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `klienci`
--

INSERT INTO `klienci` (`ID`, `imie`, `nazwisko`, `email`, `telefon`) VALUES
(1, 'Janusz', 'Kowalski', 'jan.kowalski@example.com', '123456789'),
(2, 'Anna', 'Nowak', 'anna.nowak@example.com', '987654321'),
(3, 'Piotr', 'Zieliński', 'piotr.zielinski@example.com', '456789123'),
(4, 'Katarzyna', 'Wójcik', 'katarzyna.wojcik@example.com', '321654987'),
(5, 'Marek', 'Lewandowski', 'marek.lewandowski@example.com', '789123456'),
(6, 'Karolina', 'Dąbrowska', 'karolina.dabrowska@example.com', '654321987'),
(7, 'Adam', 'Woźniak', 'adam.wozniak@example.com', '234567891');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownicy`
--

CREATE TABLE `pracownicy` (
  `ID` int(11) NOT NULL,
  `imie` varchar(50) DEFAULT NULL,
  `nazwisko` varchar(50) DEFAULT NULL,
  `data_zatrudnienia` date DEFAULT NULL,
  `stanowisko` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `pracownicy`
--

INSERT INTO `pracownicy` (`ID`, `imie`, `nazwisko`, `data_zatrudnienia`, `stanowisko`) VALUES
(1, 'Marcin', 'Nowak', '2022-01-10', 'Specjalista ds. sprzedaży'),
(2, 'Alicja', 'Kowalczyk', '2022-02-15', 'Magazynier'),
(3, 'Mateusz', 'Jankowski', '2022-03-20', 'Kierownik sklepu'),
(4, 'Natalia', 'Zielińska', '2022-04-25', 'Specjalista ds. obsługi klienta');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `produkty`
--

CREATE TABLE `produkty` (
  `ID` int(11) NOT NULL,
  `nazwa_produktu` varchar(255) DEFAULT NULL,
  `cena` decimal(10,2) DEFAULT NULL,
  `dostepnosc` int(11) DEFAULT NULL,
  `data_dodania` date DEFAULT NULL,
  `producent` varchar(50) DEFAULT NULL,
  `opis_produktu` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `produkty`
--

INSERT INTO `produkty` (`ID`, `nazwa_produktu`, `cena`, `dostepnosc`, `data_dodania`, `producent`, `opis_produktu`) VALUES
(1, 'Laptop ASUS', 2500.00, 10, '2023-01-15', 'ASUS', NULL),
(2, 'Drukarka HP', 350.00, 5, '2023-02-20', 'HP', NULL),
(3, 'Mysz bezprzewodowa', 50.00, 20, '2023-03-10', 'Logitech', NULL),
(4, 'Monitor Dell', 600.00, 8, '2023-04-05', 'Dell', NULL),
(5, 'Router TP-Link', 80.00, 15, '2023-05-12', 'TP-Link', NULL),
(6, 'Słuchawki Sony', 120.00, 12, '2023-06-18', 'Sony', NULL),
(7, 'Klawiatura gamingowa', 150.00, 18, '2023-07-22', 'Corsair', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `szczegoly_zamowienia`
--

CREATE TABLE `szczegoly_zamowienia` (
  `ID` int(11) NOT NULL,
  `zamowienie_id` int(11) DEFAULT NULL,
  `produkt_id` int(11) DEFAULT NULL,
  `ilosc` int(11) DEFAULT NULL,
  `cena_jednostkowa` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `szczegoly_zamowienia`
--

INSERT INTO `szczegoly_zamowienia` (`ID`, `zamowienie_id`, `produkt_id`, `ilosc`, `cena_jednostkowa`) VALUES
(1, 1, 1, 1, 2500.00),
(2, 2, 3, 2, 100.00),
(3, 3, 5, 3, 40.00),
(4, 4, 2, 1, 350.00),
(5, 5, 4, 2, 300.00),
(6, 6, 6, 1, 120.00),
(7, 7, 7, 2, 150.00);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zamowienia`
--

CREATE TABLE `zamowienia` (
  `ID` int(11) NOT NULL,
  `data_zamowienia` date DEFAULT NULL,
  `kwota_totalna` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `klient_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `zamowienia`
--

INSERT INTO `zamowienia` (`ID`, `data_zamowienia`, `kwota_totalna`, `status`, `klient_id`) VALUES
(1, '2023-01-20', 5000.00, 'Realizowane', 1),
(2, '2023-03-05', 800.00, 'Wysłane', 2),
(3, '2023-04-18', 120.00, 'Zrealizowane', 3),
(4, '2023-05-25', 2400.00, 'W trakcie realizacji', 4),
(5, '2023-06-30', 720.00, 'Anulowane', 5),
(6, '2023-08-10', 900.00, 'Realizowane', 6),
(7, '2023-09-15', 1500.00, 'W trakcie realizacji', 7);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `kategorie`
--
ALTER TABLE `kategorie`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `klienci`
--
ALTER TABLE `klienci`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `produkty`
--
ALTER TABLE `produkty`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `szczegoly_zamowienia`
--
ALTER TABLE `szczegoly_zamowienia`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `zamowienie_id` (`zamowienie_id`),
  ADD KEY `produkt_id` (`produkt_id`);

--
-- Indeksy dla tabeli `zamowienia`
--
ALTER TABLE `zamowienia`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `klient_id` (`klient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategorie`
--
ALTER TABLE `kategorie`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `klienci`
--
ALTER TABLE `klienci`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pracownicy`
--
ALTER TABLE `pracownicy`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `produkty`
--
ALTER TABLE `produkty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `szczegoly_zamowienia`
--
ALTER TABLE `szczegoly_zamowienia`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `zamowienia`
--
ALTER TABLE `zamowienia`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `szczegoly_zamowienia`
--
ALTER TABLE `szczegoly_zamowienia`
  ADD CONSTRAINT `szczegoly_zamowienia_ibfk_1` FOREIGN KEY (`zamowienie_id`) REFERENCES `zamowienia` (`ID`),
  ADD CONSTRAINT `szczegoly_zamowienia_ibfk_2` FOREIGN KEY (`produkt_id`) REFERENCES `produkty` (`ID`);

--
-- Constraints for table `zamowienia`
--
ALTER TABLE `zamowienia`
  ADD CONSTRAINT `zamowienia_ibfk_1` FOREIGN KEY (`klient_id`) REFERENCES `klienci` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
